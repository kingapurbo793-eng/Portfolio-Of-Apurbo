# Apurbo Roy Biswajit — Personal Portfolio

A premium, dark-themed, single-page personal portfolio website for Apurbo Roy Biswajit — Web Developer, Student &amp; Designer at Tejia Government High School.

## Sections
Home · About · Skills · Projects · Services · Experience · Blog · Contact · CV Download

## How to publish on GitHub Pages

1. Create a new repository (e.g. `apurbo-portfolio`).
2. Upload these to the repo root, keeping the same names:
   - `index.html`
   - `assets/` (folder)
   - `README.md`
3. Go to **Settings → Pages**.
4. Set **Source** to `Deploy from a branch`, **Branch** to `main`, folder `/ (root)`, then **Save**.
5. In 1–2 minutes your site will be live at:
   `https://<your-username>.github.io/apurbo-portfolio/`

## Before going live

- Add your real CV as `assets/Apurbo_Roy_Biswajit_CV.pdf` — the "Download CV" buttons already point to this exact path.
- Replace the placeholder project thumbnails and blog images in the `assets/` folder with real ones if you'd like, and update the image references inside `index.html`.
- Update the "Live Demo" / "Source Code" / "Read More" links in `index.html` once you have real project and blog URLs.

## Tech
Pure HTML, CSS and JavaScript — no frameworks, no build step. Everything lives in one `index.html` file.
